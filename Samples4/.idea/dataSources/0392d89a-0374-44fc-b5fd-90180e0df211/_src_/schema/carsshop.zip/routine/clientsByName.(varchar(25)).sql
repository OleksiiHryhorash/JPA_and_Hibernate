CREATE PROCEDURE `clientsByName`(IN `cname` VARCHAR(25))
  BEGIN
   IF (cname IS NOT NULL)  
   THEN
	
	SELECT * FROM clients WHERE name like cname; 
    ELSE				
	
	SELECT 'Bad error';
    END IF;
 END