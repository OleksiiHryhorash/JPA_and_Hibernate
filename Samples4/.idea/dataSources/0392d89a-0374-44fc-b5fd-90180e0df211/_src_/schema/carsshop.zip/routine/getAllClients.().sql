CREATE PROCEDURE `getAllClients`()
  BEGIN
    SELECT * FROM clients;
END