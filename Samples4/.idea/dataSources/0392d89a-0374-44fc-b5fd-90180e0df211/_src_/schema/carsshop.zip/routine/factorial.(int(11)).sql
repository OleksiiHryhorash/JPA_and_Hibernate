CREATE PROCEDURE `factorial`(IN `valueIn` INT(11))
  BEGIN
	DECLARE inWorking int DEFAULT 1;
    DECLARE result int DEFAULT 1;
    
	WHILE (inWorking <= valueIn)
	 DO
		SET result = result * inWorking;
		SET inWorking = inWorking + 1;
    END WHILE;
    
    SELECT result;
END